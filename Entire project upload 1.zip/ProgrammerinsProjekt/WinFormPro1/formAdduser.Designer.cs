﻿namespace WinFormPro1
{
    partial class formAdduser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formAdduser));
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.labelAdduserTitle = new System.Windows.Forms.Label();
            this.textBoxAdduserUsername = new System.Windows.Forms.TextBox();
            this.textBoxAdduserPassword = new System.Windows.Forms.TextBox();
            this.buttonAdduserAdd = new System.Windows.Forms.Button();
            this.checkBoxShowpassword = new System.Windows.Forms.CheckBox();
            this.menuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(784, 24);
            this.menuStrip.TabIndex = 0;
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.closeToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click);
            // 
            // labelAdduserTitle
            // 
            this.labelAdduserTitle.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelAdduserTitle.AutoSize = true;
            this.labelAdduserTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAdduserTitle.Location = new System.Drawing.Point(342, 35);
            this.labelAdduserTitle.Name = "labelAdduserTitle";
            this.labelAdduserTitle.Size = new System.Drawing.Size(91, 25);
            this.labelAdduserTitle.TabIndex = 1;
            this.labelAdduserTitle.Text = "Add user";
            // 
            // textBoxAdduserUsername
            // 
            this.textBoxAdduserUsername.Location = new System.Drawing.Point(267, 112);
            this.textBoxAdduserUsername.Name = "textBoxAdduserUsername";
            this.textBoxAdduserUsername.Size = new System.Drawing.Size(239, 20);
            this.textBoxAdduserUsername.TabIndex = 2;
            // 
            // textBoxAdduserPassword
            // 
            this.textBoxAdduserPassword.Location = new System.Drawing.Point(267, 138);
            this.textBoxAdduserPassword.Name = "textBoxAdduserPassword";
            this.textBoxAdduserPassword.PasswordChar = '*';
            this.textBoxAdduserPassword.Size = new System.Drawing.Size(239, 20);
            this.textBoxAdduserPassword.TabIndex = 3;
            // 
            // buttonAdduserAdd
            // 
            this.buttonAdduserAdd.Location = new System.Drawing.Point(347, 164);
            this.buttonAdduserAdd.Name = "buttonAdduserAdd";
            this.buttonAdduserAdd.Size = new System.Drawing.Size(75, 23);
            this.buttonAdduserAdd.TabIndex = 4;
            this.buttonAdduserAdd.Text = "Add user";
            this.buttonAdduserAdd.UseVisualStyleBackColor = true;
            this.buttonAdduserAdd.Click += new System.EventHandler(this.buttonAdduserAdd_Click);
            // 
            // checkBoxShowpassword
            // 
            this.checkBoxShowpassword.AutoSize = true;
            this.checkBoxShowpassword.Location = new System.Drawing.Point(512, 141);
            this.checkBoxShowpassword.Name = "checkBoxShowpassword";
            this.checkBoxShowpassword.Size = new System.Drawing.Size(101, 17);
            this.checkBoxShowpassword.TabIndex = 5;
            this.checkBoxShowpassword.Text = "Show password";
            this.checkBoxShowpassword.UseVisualStyleBackColor = true;
            this.checkBoxShowpassword.CheckedChanged += new System.EventHandler(this.checkBoxShowpassword_CheckedChanged);
            // 
            // formAdduser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WinFormPro1.Properties.Resources.Personal_Crowd_Silhouettes_Human_Group_Of_People_2045498;
            this.ClientSize = new System.Drawing.Size(784, 411);
            this.Controls.Add(this.checkBoxShowpassword);
            this.Controls.Add(this.buttonAdduserAdd);
            this.Controls.Add(this.textBoxAdduserPassword);
            this.Controls.Add(this.textBoxAdduserUsername);
            this.Controls.Add(this.labelAdduserTitle);
            this.Controls.Add(this.menuStrip);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip;
            this.Name = "formAdduser";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add user";
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.Label labelAdduserTitle;
        private System.Windows.Forms.TextBox textBoxAdduserUsername;
        private System.Windows.Forms.TextBox textBoxAdduserPassword;
        private System.Windows.Forms.Button buttonAdduserAdd;
        private System.Windows.Forms.CheckBox checkBoxShowpassword;
    }
}