﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics.Eventing.Reader;

namespace WinFormPro1
{
    public partial class formAdduser : Form
    {
        //Made to save each users information in a separate textfile. Suboptimal but functional for now.
        int loginnr;

        public formAdduser()
        {
            InitializeComponent();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        { //Will close this window and save current number of login to "loginnr.txt" in "..\bin\Debug"
            this.Close();
            using (StreamWriter streamWriter2 = new StreamWriter("loginnr.txt")) // Uses the StreamWriter function to send text from
            {                                                                    // my program to (in this case) "loginnr.txt"
                streamWriter2.WriteLine(loginnr.ToString());
            }
        }

        private void buttonAdduserAdd_Click(object sender, EventArgs e)
        { //Trying to write the username and password to a txt file in Resources
            using (StreamReader streamReader = new StreamReader("loginnr.txt")) // Uses the StreamReader function to read the previously saved/created
            {                                                                   // "loginnr.txt" file to see which the next login should be named
                loginnr = int.Parse(streamReader.ReadLine());
            }
            loginnr++;
            using (StreamWriter streamWriter = new StreamWriter("username" + loginnr + ".txt")) // Sends the username input to "usernameX.txt" where X is "loginnr.txt"
            {
                streamWriter.WriteLine(textBoxAdduserUsername.Text);
            }
            using (StreamWriter streamWriter = new StreamWriter("password" + loginnr + ".txt")) // Sends the password input to "passwordX.txt" where X is "loginnr.txt"
            {
                streamWriter.WriteLine(textBoxAdduserPassword.Text);
            }
            using (StreamWriter streamWriter2 = new StreamWriter("loginnr.txt")) // Sends the current login place to previously mentioned "loginnr.txt" file
            {
                streamWriter2.WriteLine(loginnr.ToString());
            }
            textBoxAdduserUsername.Text = ""; // Clearing username textbox on completition
            textBoxAdduserPassword.Text = ""; // Clearing password textbox on completition
        }

        private void checkBoxShowpassword_CheckedChanged(object sender, EventArgs e)
        {
            if (textBoxAdduserPassword.PasswordChar == '*')
            {
                textBoxAdduserPassword.PasswordChar = '\0';
            }
            else
            {
                textBoxAdduserPassword.PasswordChar = '*';
            }
        }
    }
}
