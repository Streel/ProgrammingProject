﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WinFormPro1
{
    public partial class formConsole : Form
    {
        bool newuser1 = false; //Used in creatin of new user through console. Step 3
        bool newuser2 = false; //Used in creatin of new user through console. Step 2
        formAdduser formUser = new formAdduser(); //Used to open New user window through console

        public formConsole()
        {
            InitializeComponent();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide(); // Will close the console window
        }

        private void runCommandToolStripMenuItem_Click(object sender, EventArgs e) //Commands will be ran when button in menu is used
        {

            // Following three if statements will run to create a new account though the console
            // This is usable in case of password loss but is also a vurnebility I could exploit
            //Order explained in file ..\WinFormPro1\Resources\OrderExplanationConsoleNewuser.png
            int loginnr = 0;
            if (newuser2) //This will run as the 3rd and final step
            {
                using (StreamReader streamReader = new StreamReader("loginnr.txt")) //Check the loginnr from text file since reset 3rows above
                {
                    loginnr = int.Parse(streamReader.ReadLine()); //Create copy of loginnr
                }
                using (StreamWriter streamWriter = new StreamWriter("password" + loginnr + ".txt")) //Write new password in new textfile
                {
                    streamWriter.WriteLine(richTextBoxConsole.Text);
                }
                newuser2 = false; //Deactivate New user command and unlock for potential new commands
            }
            if (newuser1) //This will run as the 2nd step
            {
                using (StreamReader streamReader = new StreamReader("loginnr.txt")) //Check the loginnr from text file
                {
                    loginnr = int.Parse(streamReader.ReadLine()); //Create copy of loginnr
                }
                loginnr++; //Update loginnr
                using (StreamWriter streamWriter = new StreamWriter("loginnr.txt")) //Place new loginnr in text file
                {
                    streamWriter.WriteLine(loginnr.ToString());
                }
                using (StreamWriter streamWriter = new StreamWriter("username" + loginnr + ".txt")) //Write new username in new textfile
                {
                    streamWriter.WriteLine(richTextBoxConsole.Text);
                }
                newuser1 = false; //Deactivate this step so as to not interfer with the next step
                newuser2 = true;  //Proceed to next step after using button "Run command"
                richTextBoxConsole.Text = "replace this text with new password (it cannot be adduser)"; //Ask user for new password
            }
            if (richTextBoxConsole.Text == "adduser") //This will run as the first step
            {
                richTextBoxConsole.Text = "replace this text with new username (it cannot be adduser)"; //Ask user for new username
                newuser1 = true; //Proceed to next step after using button "Run command"
            }
            if (richTextBoxConsole.Text == "windowUser") //Show "New user" form
            {
                formUser.Show();
            }
        }
    }
}
