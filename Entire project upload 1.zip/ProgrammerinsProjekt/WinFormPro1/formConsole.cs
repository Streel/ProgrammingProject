﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WinFormPro1
{
    public partial class formConsole : Form
    {
        bool newuser1 = false; //Used in creatin of new user through console. Step 3
        bool newuser2 = false; //Used in creatin of new user through console. Step 2
        formAdduser formUser = new formAdduser(); //Used to open New user window through console

        public formConsole()
        {
            InitializeComponent();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide(); // Will close the console window
        }

        private void runCommandToolStripMenuItem_Click(object sender, EventArgs e) //Commands will be ran when button in menu is used
        {
            if (richTextBoxConsole.Text == "windowUser") //Show "New user" form
            {
                formUser.Show();
            }
        }
    }
}
