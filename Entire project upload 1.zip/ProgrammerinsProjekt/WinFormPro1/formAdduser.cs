﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics.Eventing.Reader;
using System.Security.Cryptography;

namespace WinFormPro1
{
    public partial class formAdduser : Form
    {
        public string cryptPassword = "5blåelefantersomtyckerom765gulacyklar";

        //Made to save each users information in a separate textfile. Suboptimal but functional for now.
        public formAdduser()
        {
            InitializeComponent();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        { //Will close this window
            this.Hide();
        }

        public void buttonAdduserAdd_Click(object sender, EventArgs e)
        { //Trying to write the username and password to a txt file in Resources
            int loginnr = 0;
            using (StreamReader streamReader = new StreamReader("loginnr.txt")) // Uses the StreamReader function to read the previously saved/created
            {                                                                   // "loginnr.txt" file to see which the next login should be named
                loginnr = int.Parse(streamReader.ReadLine());
            }
            loginnr++;

            using (StreamWriter streamWriter = new StreamWriter("username" + loginnr + ".txt")) // Sends the username input to "usernameX.txt" where X is "loginnr.txt"
            {
                streamWriter.WriteLine(textBoxAdduserUsername.Text);
            }
            
            using (StreamWriter streamWriter = new StreamWriter("password" + loginnr + ".txt")) // Sends the password input to "passwordX.txt" where X is "loginnr.txt"
            {
                streamWriter.WriteLine(encryptor(textBoxAdduserPassword.Text, cryptPassword)); // Encrypts the password input before sending
            }           

            using (StreamWriter streamWriter2 = new StreamWriter("loginnr.txt")) // Sends the current login place to previously mentioned "loginnr.txt" file
            {
                streamWriter2.WriteLine(loginnr.ToString());
            }          

            textBoxAdduserUsername.Text = ""; // Clearing username textbox on completition
            textBoxAdduserPassword.Text = ""; // Clearing password textbox on completition
        }

        private void checkBoxShowpassword_CheckedChanged(object sender, EventArgs e) // Changes between stars and text in the password box
        {
            if (textBoxAdduserPassword.PasswordChar == '*')
            {
                textBoxAdduserPassword.PasswordChar = '\0';
            }
            else
            {
                textBoxAdduserPassword.PasswordChar = '*';
            }
        }

        public const int KeySize = 128; // Sets the key size for the encryptor
        public const int Iterations = 1000; // Sets the number ot iterations for the encryptor

        public static string encryptor(string password, string cryptPassword) //This will encrypt the inputted password and output the encrypted message
        {            
            var saltBytes = Generate256Entropy(); // Generates the random base for the encyption
            var ivBytes = Generate256Entropy(); // Generates the random base for the encyption
            var passwordBytes = Encoding.UTF8.GetBytes(password); // Converts input string into byte array

            using (var cryptSaltIterations = new Rfc2898DeriveBytes(cryptPassword, saltBytes, Iterations)) // Runs following code with set inputs
            {
                var passwordCryptSaltIter = cryptSaltIterations.GetBytes(KeySize / 8);
                using (var symmetricKey = new RijndaelManaged())
                {   //Creating key for encryptions
                    symmetricKey.BlockSize = KeySize;
                    symmetricKey.Mode = CipherMode.CBC;
                    symmetricKey.Padding = PaddingMode.PKCS7;
                    using (var symmetricKeyEncryptor = symmetricKey.CreateEncryptor(passwordCryptSaltIter, ivBytes)) //Will finalize the encryptor "machine"
                    {
                        using (var memoryStream = new MemoryStream()) //Prepares transfers
                        {
                            using (var cryptoStream = new CryptoStream(memoryStream, symmetricKeyEncryptor, CryptoStreamMode.Write)) //Encypts and returns value
                            {
                                cryptoStream.Write(passwordBytes, 0, passwordBytes.Length);
                                cryptoStream.FlushFinalBlock();
                                var cipherTextBytes = saltBytes;
                                cipherTextBytes = cipherTextBytes.Concat(ivBytes).ToArray();
                                cipherTextBytes = cipherTextBytes.Concat(memoryStream.ToArray()).ToArray();
                                memoryStream.Close();
                                cryptoStream.Close();
                                return Convert.ToBase64String(cipherTextBytes);
                            }
                        }
                    }
                }
            }
        }
        public static byte[] Generate256Entropy() // Will generate the random entropy we need
        {
            var EntropyRandom = new byte[16];
            using (var RanNumGenVal = new RNGCryptoServiceProvider())
            {
                RanNumGenVal.GetBytes(EntropyRandom);
            }
            return EntropyRandom;
        }
    }
}
