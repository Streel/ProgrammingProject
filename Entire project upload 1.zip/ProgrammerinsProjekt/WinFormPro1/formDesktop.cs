﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Design.Serialization;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Permissions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace WinFormPro1
{
    public partial class formDesktop : Form
    {
        formAdduser formUser = new formAdduser();
        formConsole formCon = new formConsole();
        public int loginnr;
        public string username;
        public string password;
        public int KeySize = 128;
        public int Iterations = 1000;
        string cryptPassword = "5blåelefantersomtyckerom765gulacyklar";

        public formDesktop()
        {
            InitializeComponent();
        }

        private void powerOffToolStripMenuItem_Click(object sender, EventArgs e)
        { //Will close the entire program
            this.Close();
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        { //Will log the user out by hiding everything on the screen and instead show the required inputs for login again.
          //Will also block all activity apart from logging in, powering down and potentially debugging in case of password loss.
            labelWronginput.Visible = true;
            pictureBoxUserimageLogin.Visible = true;
            textBoxPassword.Visible = true;
            textBoxUsername.Visible = true;
            this.BackgroundImage = Properties.Resources.login;
            buttonLogin.Visible = true;
            textBoxPassword.Text = "";
            textBoxUsername.Text = "";
            labelWronginput.Visible = false;
            newUserToolStripMenuItem.Enabled = false;
            checkBoxShowpassword.Visible = true;
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        { //Will log user in
            bool valid = false;
            if (validlogin(valid)) 
              //Will see if username and password match with login information.
            { //Will hide login input methods and instead show the desktop
                labelWronginput.Visible = false;
                pictureBoxUserimageLogin.Visible = false;
                textBoxPassword.Visible = false;
                textBoxUsername.Visible = false;
                this.BackgroundImage = Properties.Resources.desktop;
                buttonLogin.Visible = false;
                newUserToolStripMenuItem.Enabled = true;
                checkBoxShowpassword.Visible = false;
            }
            else
            {
                labelWronginput.Visible = true;
            }
        }

        private void newUserToolStripMenuItem_Click(object sender, EventArgs e)
        { //Will show "Add user" window
            formUser.Show();
        }

        public bool validlogin(bool valid)
        {
            using (StreamReader streamReader = new StreamReader("loginnr.txt")) // Sets loginnr to new variable
            {                                                                   
                loginnr = int.Parse(streamReader.ReadLine());
            }
            for (int i = 1; i <= loginnr; i++) // Loops through every login
            {
                using (StreamReader streamReader = new StreamReader("username" + i + ".txt")) // Reads the currently relevant username
                {                                                                             // and converts it into new variable "username"
                    username = (streamReader.ReadLine());
                }
                using (StreamReader streamReader = new StreamReader("password" + i + ".txt")) // Reads the currently relevant password
                {                                                                             // and converts it into new variable "password"
                    password = (decryptor(streamReader.ReadLine(), cryptPassword));
                }
                if (username == textBoxUsername.Text && password == textBoxPassword.Text)     // If the login credentials match the ones
                {                                                                             // in the respective textfiles, allow login.
                    return valid = true;
                }
            }
            return valid=false;
        }

        private void checkBoxShowpassword_CheckedChanged(object sender, EventArgs e) // Will toggle visibility of password
        {
            if (textBoxPassword.PasswordChar == '*')
            {
                textBoxPassword.PasswordChar = '\0'; // \0 here sets the password character back to default state
            }
            else
            {
                textBoxPassword.PasswordChar = '*';
            }
        }

        private void consoleToolStripMenuItem_Click(object sender, EventArgs e) // Will open the console window
        {
            formCon.Show();
        }

        public string decryptor(string password, string cryptPassword)
        {
            var inputSaltIv = Convert.FromBase64String(password); //Converts text input to byte array
            var saltBytes = inputSaltIv.Take(KeySize / 8).ToArray(); //Generates salt bytes from previous information
            var ivBytes = inputSaltIv.Skip(KeySize / 8).Take(KeySize / 8).ToArray(); //Generates iv bytes from previous information
            var inputBytes = inputSaltIv.Skip((KeySize / 8) * 2).Take(inputSaltIv.Length - ((KeySize / 8) * 2)).ToArray(); //Merges inputs

            using (var cryptUnlocker = new Rfc2898DeriveBytes(cryptPassword, saltBytes, Iterations)) //Starts decryption process
            {
                var unlockerBytes = cryptUnlocker.GetBytes(KeySize / 8); //converts unlocker into bytes
                using (var symmetricKey = new RijndaelManaged()) //Creates proper key
                {
                    symmetricKey.BlockSize = KeySize; //Sets key size
                    symmetricKey.Mode = CipherMode.CBC; //Sets key cipher
                    symmetricKey.Padding = PaddingMode.PKCS7; //Sets key padding
                    using (var symmetricKeyDecryptor = symmetricKey.CreateDecryptor(unlockerBytes, ivBytes)) //Derypts symmetrickey
                    {
                        using (var memoryStream = new MemoryStream(inputBytes)) //Starts mem stream
                        {
                            using (var cryptoStream = new CryptoStream(memoryStream, symmetricKeyDecryptor, CryptoStreamMode.Read)) //starts crypto stream
                            {                                                   //Encrypted message will be decrypted here
                                var outputBytes = new byte[inputBytes.Length];
                                var decryptedByteCount = cryptoStream.Read(outputBytes, 0, outputBytes.Length);
                                memoryStream.Close();
                                cryptoStream.Close();
                                return Encoding.UTF8.GetString(outputBytes, 0, decryptedByteCount); //Returns decrypted password
                            }
                        }
                    }
                }
            }
        }
    }
}

//  Profiles
//  The "dictionary"