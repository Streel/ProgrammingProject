﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Security.Cryptography;

namespace WinFormPro1
{
    class ConsoleApp2
    {
        public const int KeySize = 128;
        public const int Iterations = 1000;
        static void Main(string[] args)
        {
            Console.WriteLine("Write your password");
            string originalPassword = Console.ReadLine();
            string cryptPassword = "5blåelefantertycketom765gulacyklar";

            string encryptedPassword = encryptor(originalPassword, cryptPassword);
            string decryptedPassword = decryptor(encryptedPassword, cryptPassword);

            Console.WriteLine("The encrypted password is: " + encryptedPassword);
            Console.WriteLine("The decrypted password is: " + decryptedPassword);
        }
        public static string encryptor(string password, string cryptPassword) //This will encrypt the inputted password and output the encrypted message
        {
            var saltBytes = Generate256Entropy(); // Generates the random base for the encyption
            var ivBytes = Generate256Entropy(); // Generates the random base for the encyption
            var passwordBytes = Encoding.UTF8.GetBytes(password); // Converts input string into byte array

            using (var cryptSaltIterations = new Rfc2898DeriveBytes(cryptPassword, saltBytes, Iterations)) // Runs following code with set inputs
            {
                var passwordCryptSaltIter = cryptSaltIterations.GetBytes(KeySize / 8);
                using (var symmetricKey = new RijndaelManaged())
                {   //Creating key for encryptions
                    symmetricKey.BlockSize = KeySize;
                    symmetricKey.Mode = CipherMode.CBC;
                    symmetricKey.Padding = PaddingMode.PKCS7;
                    using (var symmetricKeyEncryptor = symmetricKey.CreateEncryptor(passwordCryptSaltIter, ivBytes)) //Will finalize the encryptor "machine"
                    {
                        using (var memoryStream = new MemoryStream()) //Prepares transfers
                        {
                            using (var cryptoStream = new CryptoStream(memoryStream, symmetricKeyEncryptor, CryptoStreamMode.Write)) //Encypts and returns value
                            {
                                cryptoStream.Write(passwordBytes, 0, passwordBytes.Length);
                                cryptoStream.FlushFinalBlock();
                                var cipherTextBytes = saltBytes;
                                cipherTextBytes = cipherTextBytes.Concat(ivBytes).ToArray();
                                cipherTextBytes = cipherTextBytes.Concat(memoryStream.ToArray()).ToArray();
                                memoryStream.Close();
                                cryptoStream.Close();
                                return Convert.ToBase64String(cipherTextBytes);
                            }
                        }
                    }
                }
            }
        }
        public static byte[] Generate256Entropy() // Will generate the random entropy we need
        {
            var EntropyRandom = new byte[16];
            using (var RanNumGenVal = new RNGCryptoServiceProvider())
            {
                RanNumGenVal.GetBytes(EntropyRandom);
            }
            return EntropyRandom;
        }
        public static string decryptor(string password, string cryptPassword)
        {
            var inputSaltIv = Convert.FromBase64String(password); //Converts text input to byte array
            var saltBytes = inputSaltIv.Take(KeySize / 8).ToArray(); //Generates salt bytes from previous information
            var ivBytes = inputSaltIv.Skip(KeySize / 8).Take(KeySize / 8).ToArray(); //Generates iv bytes from previous information
            var inputBytes = inputSaltIv.Skip((KeySize / 8) * 2).Take(inputSaltIv.Length - ((KeySize / 8) * 2)).ToArray(); //Merges inputs

            using (var cryptUnlocker = new Rfc2898DeriveBytes(cryptPassword, saltBytes, Iterations)) //Starts decryption process
            {
                var unlockerBytes = cryptUnlocker.GetBytes(KeySize / 8); //converts unlocker into bytes
                using (var symmetricKey = new RijndaelManaged()) //Creates proper key
                {
                    symmetricKey.BlockSize = KeySize; //Sets key size
                    symmetricKey.Mode = CipherMode.CBC; //Sets key cipher
                    symmetricKey.Padding = PaddingMode.PKCS7; //Sets key padding
                    using (var symmetricKeyDecryptor = symmetricKey.CreateDecryptor(unlockerBytes, ivBytes)) //Derypts symmetrickey
                    {
                        using (var memoryStream = new MemoryStream(inputBytes)) //Starts mem stream
                        {
                            using (var cryptoStream = new CryptoStream(memoryStream, symmetricKeyDecryptor, CryptoStreamMode.Read)) //starts crypto stream
                            {                                                   //Encrypted message will be decrypted here
                                var outputBytes = new byte[inputBytes.Length];
                                var decryptedByteCount = cryptoStream.Read(outputBytes, 0, outputBytes.Length);
                                memoryStream.Close();
                                cryptoStream.Close();
                                return Encoding.UTF8.GetString(outputBytes, 0, decryptedByteCount); //Returns decrypted password
                            }
                        }
                    }
                }
            }
        }
    }
}